export declare function formatNumber(value: any, format?: string): string;
export declare function formatCurrency(value: any, symbol?: string, format?: string): string;
