import { SVGAttributes } from 'react';
declare function CustomAhamove(props: SVGAttributes<SVGElement>): import("react/jsx-runtime").JSX.Element;
export default CustomAhamove;
