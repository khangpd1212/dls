import { SVGAttributes } from 'react';
declare function CustomNhanhVn(props: SVGAttributes<SVGElement>): import("react/jsx-runtime").JSX.Element;
export default CustomNhanhVn;
