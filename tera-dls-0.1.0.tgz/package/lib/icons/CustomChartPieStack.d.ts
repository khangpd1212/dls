import { SVGAttributes } from 'react';
declare function CustomChartPieStack(props: SVGAttributes<SVGElement>): import("react/jsx-runtime").JSX.Element;
export default CustomChartPieStack;
