import { SVGAttributes } from 'react';
declare function CustomCartShoppingBolt(props: SVGAttributes<SVGElement>): import("react/jsx-runtime").JSX.Element;
export default CustomCartShoppingBolt;
