import { SVGAttributes } from 'react';
declare function CustomTpos(props: SVGAttributes<SVGElement>): import("react/jsx-runtime").JSX.Element;
export default CustomTpos;
