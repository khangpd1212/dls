import { SVGAttributes } from 'react';
declare function CustomChartPieHeart(props: SVGAttributes<SVGElement>): import("react/jsx-runtime").JSX.Element;
export default CustomChartPieHeart;
