import { SVGAttributes } from 'react';
declare function CustomKiotViet(props: SVGAttributes<SVGElement>): import("react/jsx-runtime").JSX.Element;
export default CustomKiotViet;
