import { SVGAttributes } from 'react';
declare function CustomTiki(props: SVGAttributes<SVGElement>): import("react/jsx-runtime").JSX.Element;
export default CustomTiki;
