import { SVGAttributes } from 'react';
declare function CustomDocumentExport(props: SVGAttributes<SVGElement>): import("react/jsx-runtime").JSX.Element;
export default CustomDocumentExport;
