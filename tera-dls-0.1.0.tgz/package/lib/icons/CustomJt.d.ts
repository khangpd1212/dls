import { SVGAttributes } from 'react';
declare function CustomJt(props: SVGAttributes<SVGElement>): import("react/jsx-runtime").JSX.Element;
export default CustomJt;
