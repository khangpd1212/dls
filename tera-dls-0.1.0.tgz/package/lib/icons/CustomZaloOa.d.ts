import { SVGAttributes } from 'react';
declare function CustomZaloOa(props: SVGAttributes<SVGElement>): import("react/jsx-runtime").JSX.Element;
export default CustomZaloOa;
