import { SVGAttributes } from 'react';
declare function CustomInstagram(props: SVGAttributes<SVGElement>): import("react/jsx-runtime").JSX.Element;
export default CustomInstagram;
