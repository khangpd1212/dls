import { SVGAttributes } from 'react';
declare function CustomDocumentReturn(props: SVGAttributes<SVGElement>): import("react/jsx-runtime").JSX.Element;
export default CustomDocumentReturn;
