import { SVGAttributes } from 'react';
declare function CustomChartPieBuilding(props: SVGAttributes<SVGElement>): import("react/jsx-runtime").JSX.Element;
export default CustomChartPieBuilding;
