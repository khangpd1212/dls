import { SVGAttributes } from 'react';
declare function CustomChartPieUserGroup(props: SVGAttributes<SVGElement>): import("react/jsx-runtime").JSX.Element;
export default CustomChartPieUserGroup;
