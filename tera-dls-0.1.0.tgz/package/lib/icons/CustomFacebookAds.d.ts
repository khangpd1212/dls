import { SVGAttributes } from 'react';
declare function CustomFacebookAds(props: SVGAttributes<SVGElement>): import("react/jsx-runtime").JSX.Element;
export default CustomFacebookAds;
