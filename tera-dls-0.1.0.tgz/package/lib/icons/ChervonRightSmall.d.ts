import { SVGAttributes } from 'react';
export declare function ChevronRightSmall(props: SVGAttributes<SVGElement>): import("react/jsx-runtime").JSX.Element;
