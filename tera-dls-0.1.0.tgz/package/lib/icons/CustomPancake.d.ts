import { SVGAttributes } from 'react';
declare function CustomPancake(props: SVGAttributes<SVGElement>): import("react/jsx-runtime").JSX.Element;
export default CustomPancake;
