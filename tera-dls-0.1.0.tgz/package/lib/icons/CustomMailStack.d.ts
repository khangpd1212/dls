import { SVGAttributes } from 'react';
declare function CustomMailStack(props: SVGAttributes<SVGElement>): import("react/jsx-runtime").JSX.Element;
export default CustomMailStack;
