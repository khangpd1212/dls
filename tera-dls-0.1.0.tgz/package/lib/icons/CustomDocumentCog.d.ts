import { SVGAttributes } from 'react';
declare function CustomDocumentCog(props: SVGAttributes<SVGElement>): import("react/jsx-runtime").JSX.Element;
export default CustomDocumentCog;
