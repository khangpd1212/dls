import { SVGAttributes } from 'react';
declare function CustomVietelPost(props: SVGAttributes<SVGElement>): import("react/jsx-runtime").JSX.Element;
export default CustomVietelPost;
