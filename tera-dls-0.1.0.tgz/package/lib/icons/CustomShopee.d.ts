import { SVGAttributes } from 'react';
declare function CustomShopee(props: SVGAttributes<SVGElement>): import("react/jsx-runtime").JSX.Element;
export default CustomShopee;
