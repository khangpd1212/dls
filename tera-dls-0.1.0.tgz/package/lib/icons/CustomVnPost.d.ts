import { SVGAttributes } from 'react';
declare function CustomVnPost(props: SVGAttributes<SVGElement>): import("react/jsx-runtime").JSX.Element;
export default CustomVnPost;
