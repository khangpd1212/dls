import { SVGAttributes } from 'react';
export declare function CustomSapo(props: SVGAttributes<SVGElement>): import("react/jsx-runtime").JSX.Element;
