import { SVGAttributes } from 'react';
declare function CustomGoogleAds(props: SVGAttributes<SVGElement>): import("react/jsx-runtime").JSX.Element;
export default CustomGoogleAds;
