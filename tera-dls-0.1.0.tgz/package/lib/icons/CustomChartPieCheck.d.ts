import { SVGAttributes } from 'react';
declare function CustomChartPieCheck(props: SVGAttributes<SVGElement>): import("react/jsx-runtime").JSX.Element;
export default CustomChartPieCheck;
