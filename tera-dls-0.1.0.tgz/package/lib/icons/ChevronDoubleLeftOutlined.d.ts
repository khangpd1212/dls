import { SVGAttributes } from 'react';
export declare function ChevronDoubleLeftOutlined(props: SVGAttributes<SVGElement>): import("react/jsx-runtime").JSX.Element;
