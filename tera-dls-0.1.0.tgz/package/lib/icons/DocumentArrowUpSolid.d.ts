import { SVGAttributes } from 'react';
export declare function DocumentArrowUpSolid(props: SVGAttributes<SVGElement>): import("react/jsx-runtime").JSX.Element;
