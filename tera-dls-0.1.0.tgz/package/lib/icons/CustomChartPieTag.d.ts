import { SVGAttributes } from 'react';
declare function CustomChartPieTag(props: SVGAttributes<SVGElement>): import("react/jsx-runtime").JSX.Element;
export default CustomChartPieTag;
