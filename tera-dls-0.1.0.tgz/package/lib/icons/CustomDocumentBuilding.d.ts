import { SVGAttributes } from 'react';
declare function CustomDocumentBuilding(props: SVGAttributes<SVGElement>): import("react/jsx-runtime").JSX.Element;
export default CustomDocumentBuilding;
