import { SVGAttributes } from 'react';
declare function CustomFacebook(props: SVGAttributes<SVGElement>): import("react/jsx-runtime").JSX.Element;
export default CustomFacebook;
