import { SVGAttributes } from 'react';
declare function CustomLazada(props: SVGAttributes<SVGElement>): import("react/jsx-runtime").JSX.Element;
export default CustomLazada;
