import { SVGAttributes } from 'react';
declare function CustomDocumentCart(props: SVGAttributes<SVGElement>): import("react/jsx-runtime").JSX.Element;
export default CustomDocumentCart;
