import { SVGAttributes } from 'react';
declare function CustomZalo(props: SVGAttributes<SVGElement>): import("react/jsx-runtime").JSX.Element;
export default CustomZalo;
