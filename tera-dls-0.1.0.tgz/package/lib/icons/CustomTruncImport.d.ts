import { SVGAttributes } from 'react';
declare function CustomTruncImport(props: SVGAttributes<SVGElement>): import("react/jsx-runtime").JSX.Element;
export default CustomTruncImport;
