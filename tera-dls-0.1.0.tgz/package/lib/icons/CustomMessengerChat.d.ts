import { SVGAttributes } from 'react';
declare function CustomMessengerChat(props: SVGAttributes<SVGElement>): import("react/jsx-runtime").JSX.Element;
export default CustomMessengerChat;
