import { SVGAttributes } from 'react';
declare function CustomDocumentUserGroup(props: SVGAttributes<SVGElement>): import("react/jsx-runtime").JSX.Element;
export default CustomDocumentUserGroup;
