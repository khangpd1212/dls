import { SVGAttributes } from 'react';
declare function CustomBuildingBolt(props: SVGAttributes<SVGElement>): import("react/jsx-runtime").JSX.Element;
export default CustomBuildingBolt;
