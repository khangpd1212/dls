import { SVGAttributes } from 'react';
declare function CustomDocumentImport(props: SVGAttributes<SVGElement>): import("react/jsx-runtime").JSX.Element;
export default CustomDocumentImport;
