import { SVGAttributes } from 'react';
declare function CustomGhn(props: SVGAttributes<SVGElement>): import("react/jsx-runtime").JSX.Element;
export default CustomGhn;
