import { SVGAttributes } from 'react';
declare function CustomCartBag(props: SVGAttributes<SVGElement>): import("react/jsx-runtime").JSX.Element;
export default CustomCartBag;
