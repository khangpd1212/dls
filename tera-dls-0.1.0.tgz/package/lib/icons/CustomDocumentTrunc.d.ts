import { SVGAttributes } from 'react';
declare function CustomDocumentTrunc(props: SVGAttributes<SVGElement>): import("react/jsx-runtime").JSX.Element;
export default CustomDocumentTrunc;
