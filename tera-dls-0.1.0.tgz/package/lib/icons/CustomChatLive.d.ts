import { SVGAttributes } from 'react';
declare function CustomChatLive(props: SVGAttributes<SVGElement>): import("react/jsx-runtime").JSX.Element;
export default CustomChatLive;
