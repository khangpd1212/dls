import { SVGAttributes } from 'react';
declare function CustomSendo(props: SVGAttributes<SVGElement>): import("react/jsx-runtime").JSX.Element;
export default CustomSendo;
