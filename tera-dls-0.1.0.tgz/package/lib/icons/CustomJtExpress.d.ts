import { SVGAttributes } from 'react';
declare function CustomJtExpress(props: SVGAttributes<SVGElement>): import("react/jsx-runtime").JSX.Element;
export default CustomJtExpress;
