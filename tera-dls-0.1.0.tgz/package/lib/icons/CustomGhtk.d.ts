import { SVGAttributes } from 'react';
declare function CustomGhtk(props: SVGAttributes<SVGElement>): import("react/jsx-runtime").JSX.Element;
export default CustomGhtk;
