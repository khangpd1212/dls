import { SVGAttributes } from 'react';
declare function CustomTruncExport(props: SVGAttributes<SVGElement>): import("react/jsx-runtime").JSX.Element;
export default CustomTruncExport;
