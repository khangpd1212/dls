/// <reference types="react" />
export type TabsType = 'line' | 'card' | 'editable-card';
export type TabsPosition = 'top' | 'right' | 'bottom' | 'left';
export interface TabsProps {
    itemClassName?: string;
    className?: string;
    items?: TabItemType[];
    defaultActiveKey?: string;
    activeKey?: string;
    onChange?: (activeKey: string) => void;
    onTabClick?: (activeKey: string, e: React.MouseEvent | React.KeyboardEvent) => void;
    tabPosition?: 'left' | 'right' | 'top' | 'bottom';
    activeClassName?: string;
}
export interface TabItemType {
    key: string;
    label: React.ReactNode;
    disabled?: boolean;
    children?: React.ReactNode;
}
declare const _default: import("react").MemoExoticComponent<{
    ({ items, defaultActiveKey, onChange, activeKey, onTabClick, className, tabPosition, itemClassName, activeClassName, }: TabsProps): import("react/jsx-runtime").JSX.Element;
    displayName: string;
}>;
export default _default;
