export declare const offset = 4;
export default function dropIndicatorRender(props: {
    dropPosition: -1 | 0 | 1;
    dropLevelOffset: number;
    indent: number;
    prefixCls: string;
    direction: 'ltr' | 'rtl';
}): import("react/jsx-runtime").JSX.Element;
