import React from 'react';
interface DefaultImageProps {
    src: string;
    alt: string;
    defaultSrc?: string;
    style?: React.CSSProperties;
    className?: string;
    onClick?: () => void;
}
declare const _default: React.ForwardRefExoticComponent<DefaultImageProps & React.RefAttributes<unknown>>;
export default _default;
