import { CSSProperties } from 'react';
import { DivProps } from 'common/interfaces';
export interface ImageProps extends Omit<DivProps, 'className'> {
    src?: string;
    width?: number;
    alt?: string;
    borderRadius?: CSSProperties['borderRadius'];
    imageClassName?: string;
    containerClassName?: string;
    defaultImage?: string;
    preview?: {
        src?: string;
        visible?: boolean;
    } | boolean;
}
export type { PreviewGroupProps, PreviewGroupType } from './PreviewGroup';
declare const Image: {
    (props: ImageProps): import("react/jsx-runtime").JSX.Element;
    displayName: string;
    PreviewGroup: ({ children }: import("lib").PreviewGroupProps) => import("react/jsx-runtime").JSX.Element;
};
export default Image;
