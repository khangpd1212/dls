import { ImageProps } from '.';
declare const ImageInternal: (props: ImageProps) => import("react/jsx-runtime").JSX.Element;
export default ImageInternal;
