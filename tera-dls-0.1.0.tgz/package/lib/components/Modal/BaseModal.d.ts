import React from 'react';
import { BaseModalProps } from './interface';
declare const BaseModal: React.ForwardRefExoticComponent<BaseModalProps & React.RefAttributes<HTMLDivElement>>;
export default BaseModal;
