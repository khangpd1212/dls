/// <reference types="react" />
import ModalWindow from './ModalWindow';
declare const Modal: import("react").ForwardRefExoticComponent<import("./interface").BaseModalProps & import("react").RefAttributes<HTMLDivElement>>;
export type { ModalFuncProps, ModalLocale, BaseModalProps, ModalProps, } from './interface';
export { ModalWindow, Modal };
