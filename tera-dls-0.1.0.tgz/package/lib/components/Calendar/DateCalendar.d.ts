import { ReactNode } from 'react';
import { TimeType } from './interface';
export type DateCalendarProps = {
    listTime?: TimeType[];
    onSelect?: (value?: TimeType['value']) => void;
    cellRender?: (value?: TimeType['value']) => ReactNode;
};
declare const DateCalendar: ({ listTime, onSelect, cellRender, }: DateCalendarProps) => import("react/jsx-runtime").JSX.Element;
export default DateCalendar;
