import { BodyMonthCalendarProps } from './Body';
import { HeadMonthCalendarProps } from './Head';
import { CalendarBaseProps } from '../interface';
export type MonthCalendarProps = HeadMonthCalendarProps & BodyMonthCalendarProps & Pick<CalendarBaseProps, 'className'>;
declare const MonthCalendar: ({ fullScreen, className, mode, ...restProps }: MonthCalendarProps) => import("react/jsx-runtime").JSX.Element;
export default MonthCalendar;
