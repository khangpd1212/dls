import { CalendarBaseProps, DayInMonth } from '../interface';
export type BodyMonthCalendarProps = Pick<CalendarBaseProps, 'cellRender' | 'onSelect' | 'cellClassName'> & {
    dataSource?: {
        lastMonth: DayInMonth[];
        currentMonth: DayInMonth[];
        nextMonth: DayInMonth[];
    };
    fullScreen?: boolean;
    value?: string;
    mode?: 'dark' | 'light';
};
declare const BodyMonthCalendar: ({ onSelect, dataSource, fullScreen, cellClassName, value, mode, cellRender, }: BodyMonthCalendarProps) => import("react/jsx-runtime").JSX.Element;
export default BodyMonthCalendar;
