import { CalendarBaseProps } from '../interface';
export type HeadMonthCalendarProps = Pick<CalendarBaseProps, 'headerRender' | 'extraHeader' | 'headerClassName'> & {
    fullScreen?: boolean;
};
declare const HeadMonthCalendar: ({ extraHeader, headerRender, fullScreen, headerClassName, }: HeadMonthCalendarProps) => import("react/jsx-runtime").JSX.Element;
export default HeadMonthCalendar;
