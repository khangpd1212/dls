import { CalendarBaseProps } from './interface';
declare const Calendar: ({ ...restProps }: CalendarBaseProps) => import("react/jsx-runtime").JSX.Element;
export { default as DateCalendar } from './DateCalendar';
export type { DateCalendarProps } from './DateCalendar';
export { default as MonthCalendar } from './MonthCalendar';
export type { MonthCalendarProps } from './MonthCalendar';
export { default as WeekCalendar } from './WeekCalendar';
export type { WeekCalendarProps } from './WeekCalendar';
export default Calendar;
