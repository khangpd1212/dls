type FilterCalendarProps = {
    onChangeTypeCalendar: (value: any) => void;
    typeCalendar: any;
};
declare const FilterCalendar: ({ onChangeTypeCalendar, typeCalendar, }: FilterCalendarProps) => import("react/jsx-runtime").JSX.Element;
export default FilterCalendar;
