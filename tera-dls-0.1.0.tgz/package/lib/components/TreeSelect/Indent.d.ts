import * as React from 'react';
interface IndentProps {
    level: number;
    className?: string;
    containerClassName?: string;
}
declare const _default: React.MemoExoticComponent<({ level, className, containerClassName }: IndentProps) => import("react/jsx-runtime").JSX.Element>;
export default _default;
