import React from 'react';
export type BadgeProps = {
    count?: React.ReactNode;
    showZero?: boolean;
    overflowCount?: number;
    children?: React.ReactNode;
    containerClassName?: string;
    className?: string;
};
declare const Badge: React.ForwardRefExoticComponent<BadgeProps & React.RefAttributes<HTMLDivElement>>;
export default Badge;
