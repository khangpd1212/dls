import { Moment } from 'moment';
import { PickerProps as RcPickerDateProps } from 'rc-picker/lib';
import type { GenerateConfig } from 'rc-picker/lib/generate/index';
import { Locale, PickerRef } from 'rc-picker/lib/interface';
import { ReactElement } from 'react';
export type DatePickerProps = Omit<RcPickerDateProps<Moment>, 'locale' | 'generateConfig' | 'picker'> & {
    locale?: Locale;
    picker?: 'date' | 'month' | 'year' | 'week' | 'quarter';
    generateConfig?: GenerateConfig<Moment>;
    prefixIcon?: ReactElement;
    inputClassName?: string;
};
declare const DatePicker: import("react").ForwardRefExoticComponent<Omit<RcPickerDateProps<Moment>, "locale" | "generateConfig" | "picker"> & {
    locale?: Locale;
    picker?: 'date' | 'month' | 'year' | 'week' | 'quarter';
    generateConfig?: GenerateConfig<Moment>;
    prefixIcon?: ReactElement;
    inputClassName?: string;
} & import("react").RefAttributes<PickerRef>>;
export default DatePicker;
