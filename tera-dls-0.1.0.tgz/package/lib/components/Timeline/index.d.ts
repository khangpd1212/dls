import { ReactNode } from 'react';
export type ItemTimeline = {
    dot?: ReactNode;
    label?: ReactNode;
    children?: ReactNode;
    position?: 'left' | 'right';
    dotClassName?: string;
    tailClassName?: string;
};
export type TimelineProps = {
    mode?: 'left' | 'alternate' | 'right';
    pending?: boolean | ReactNode;
    pendingDot?: ReactNode;
    reverse?: boolean;
    items?: ItemTimeline[];
    tailClassName?: string;
    dotClassName?: string;
};
declare const Timeline: ({ mode, tailClassName, dotClassName, items, }: TimelineProps) => import("react/jsx-runtime").JSX.Element;
export default Timeline;
