export interface InputFocusOptions extends FocusOptions {
    cursor?: 'start' | 'end' | 'all';
}
export declare function triggerFocus(element?: HTMLInputElement | HTMLTextAreaElement, option?: InputFocusOptions): void;
export declare function isE(number: string | number): boolean;
export declare function getNumberPrecision(number: string | number): number;
export declare function validateNumber(num: string | number): boolean;
export declare function isEmpty(value: number): boolean;
