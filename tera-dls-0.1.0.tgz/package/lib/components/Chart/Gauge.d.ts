import { ChartProps } from 'react-chartjs-2';
import { Plugins } from './interface';
export type ChartGaugeProps = Omit<ChartProps<'gauge'>, 'type' | 'plugins'> & {
    plugins?: Plugins[];
};
declare const ChartGauge: ({ plugins, ...restProps }: ChartGaugeProps) => import("react/jsx-runtime").JSX.Element;
export default ChartGauge;
