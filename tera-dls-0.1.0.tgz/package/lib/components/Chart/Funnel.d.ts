import { ChartProps } from 'react-chartjs-2';
import { Plugins } from './interface';
export type ChartFunnelProps = Omit<ChartProps<'funnel'>, 'type' | 'plugins'> & {
    plugins?: Plugins[];
};
declare const ChartFunnel: (props: ChartFunnelProps) => import("react/jsx-runtime").JSX.Element;
export default ChartFunnel;
