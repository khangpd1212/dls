/// <reference types="react" />
import { Chart as ChartJS, ChartOptions } from 'chart.js';
import { ChartProps } from 'react-chartjs-2';
import { Plugins } from './interface';
import { Options } from 'chartjs-plugin-datalabels/types/options';
export type ChartBarProps = Omit<ChartProps<'bar'>, 'type' | 'plugins' | 'options'> & {
    plugins?: Plugins[];
    options?: ChartOptions<'bar'> & Options;
};
declare const ChartBar: import("react").ForwardRefExoticComponent<Omit<ChartProps<"bar", (number | [number, number])[], unknown>, "type" | "plugins" | "options"> & {
    plugins?: Plugins[];
    options?: ChartOptions<'bar'> & Options;
} & import("react").RefAttributes<ChartJS<"bar", (number | [number, number])[], unknown>>>;
export default ChartBar;
