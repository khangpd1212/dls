/// <reference types="react" />
import { Chart as ChartJS, ChartOptions } from 'chart.js';
import { Options } from 'chartjs-plugin-datalabels/types/options';
import { ChartProps } from 'react-chartjs-2';
import { Plugins } from './interface';
export type ChartDoughnutProps = Omit<ChartProps<'doughnut'>, 'type' | 'plugins' | 'options'> & {
    labelCenter?: string;
    plugins?: Plugins[];
    options?: ChartOptions<'doughnut'> & Options;
};
declare const ChartDoughnut: import("react").ForwardRefExoticComponent<Omit<ChartProps<"doughnut", number[], unknown>, "type" | "plugins" | "options"> & {
    labelCenter?: string;
    plugins?: Plugins[];
    options?: ChartOptions<'doughnut'> & Options;
} & import("react").RefAttributes<ChartJS<"doughnut", number[], unknown>>>;
export default ChartDoughnut;
