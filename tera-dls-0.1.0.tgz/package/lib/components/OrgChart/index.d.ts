/// <reference types="react" />
import '../../styles/component/org-chart/chart-container.scss';
import { ChartNodeProps } from './ChartNode';
export type OrgChartRef = {
    exportTo: (exportFilename: string, exportFileExtension: string) => void;
    expandAllNodes: () => void;
};
export type DataSourceType = {
    id?: number | string;
    relationship?: string;
    children?: DataSourceType[];
    [key: string]: any;
};
export type NodeTemplateCustomProps = {
    nodeData: DataSourceType;
};
export type ChartContainerProps = ChartNodeProps & {
    pan?: boolean;
    zoom?: boolean;
    zoomOutLimit?: number;
    zoomInLimit?: number;
    containerClass?: string;
    chartClass?: string;
    onClickChart?: () => void;
    style?: React.CSSProperties;
};
declare global {
    interface Window {
        sidebar: boolean;
    }
    interface Navigator {
        msSaveBlob: (canvas: any, filename: string) => void;
    }
}
declare const OrgChart: import("react").ForwardRefExoticComponent<import("./NodeTemplate").NodeTemplateProps & {
    NodeTemplateCustom?: ({ nodeData, }: NodeTemplateCustomProps) => import("react").ReactElement<NodeTemplateCustomProps, string | import("react").JSXElementConstructor<any>>;
    draggable?: boolean;
    collapsible?: boolean;
    multipleSelect?: boolean;
    changeHierarchy?: (dataTransfer: any, id: string) => void;
    onClickNode?: (dataSource: DataSourceType) => void;
    onClickEdge?: (type: "top" | "bottom", expanded: boolean) => void;
    depth?: number;
} & {
    pan?: boolean;
    zoom?: boolean;
    zoomOutLimit?: number;
    zoomInLimit?: number;
    containerClass?: string;
    chartClass?: string;
    onClickChart?: () => void;
    style?: React.CSSProperties;
} & import("react").RefAttributes<OrgChartRef>>;
export default OrgChart;
