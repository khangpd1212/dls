import { ReactElement } from 'react';
import '../../styles/component/org-chart/chart-node.scss';
import { NodeTemplateProps } from './NodeTemplate';
import { DataSourceType, NodeTemplateCustomProps } from '.';
export type ChartNodeProps = NodeTemplateProps & {
    NodeTemplateCustom?: ({ nodeData, }: NodeTemplateCustomProps) => ReactElement<NodeTemplateCustomProps>;
    draggable?: boolean;
    collapsible?: boolean;
    multipleSelect?: boolean;
    changeHierarchy?: (dataTransfer: any, id: string) => void;
    onClickNode?: (dataSource: DataSourceType) => void;
    onClickEdge?: (type: 'top' | 'bottom', expanded: boolean) => void;
    depth?: number;
};
declare const ChartNode: ({ dataSource, NodeTemplateCustom, draggable, collapsible, multipleSelect, changeHierarchy, onClickNode, onClickEdge, depth, level, handleAdd, handleEdit, handleDelete, employeeListRender, nodeContent, nodeTitle, nodeHasDelete, nodeHasNew, nodeHasUpdate, }: ChartNodeProps) => import("react/jsx-runtime").JSX.Element;
export default ChartNode;
