import { Placement } from '@floating-ui/react-dom';
import { Key, ReactElement, ReactNode } from 'react';
export interface DropdownItem {
    icon?: React.ReactNode;
    label?: React.ReactNode;
    disabled?: boolean;
    key: Key;
    onClick?: (item: DropdownItem, key?: Key) => void;
    value?: Key;
}
export interface MenuDropdownProps {
    selectable?: boolean;
    defaultSelectedKey?: string;
    onChangeItem?: (item: DropdownItem, key?: Key) => void;
    itemClassName?: string;
    selectedKeys?: Key;
    items?: Array<DropdownItem>;
}
export interface DropdownProps {
    menu?: MenuDropdownProps;
    containerClassName?: string;
    children?: ReactElement;
    trigger?: 'click' | 'hover' | 'contextMenu';
    placement?: Placement;
    open?: boolean;
    getPopupContainer?: () => Element | DocumentFragment;
    onOpenChange?: (open: boolean) => void;
    disabled?: boolean;
    dropdownRender?: (menus: ReactNode) => ReactNode;
}
export type DropdownRef = {
    referenceRef: React.MutableRefObject<HTMLDivElement>;
    dropdownRef: React.MutableRefObject<HTMLElement>;
};
declare const Dropdown: import("react").ForwardRefExoticComponent<DropdownProps & import("react").RefAttributes<DropdownRef>>;
export default Dropdown;
