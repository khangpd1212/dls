import React from 'react';
export type AvatarProps = {
    alt?: string;
    src?: React.ReactNode;
    icon?: React.ReactNode;
    children?: React.ReactNode;
    srcSet?: string;
    size?: number;
    className?: string;
};
declare const Avatar: React.ForwardRefExoticComponent<AvatarProps & React.RefAttributes<HTMLSpanElement>>;
export default Avatar;
