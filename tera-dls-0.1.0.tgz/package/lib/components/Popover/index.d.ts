import { Placement } from '@floating-ui/react-dom';
import { ReactElement, ReactNode } from 'react';
export interface PopoverProps {
    content?: ReactNode;
    title?: ReactNode;
    children?: ReactElement;
    placement?: Placement;
    trigger?: 'hover' | 'focus' | 'click' | 'contextMenu';
    className?: string;
    open?: boolean;
    onOpenChange?: (open: boolean) => void;
    showArrow?: boolean;
    getPopupContainer?: () => Element | DocumentFragment;
    classNameTitle?: string;
    autoLock?: boolean;
    autoDestroy?: boolean;
}
declare const Popover: ({ children, placement: customPlacement, onOpenChange, open, title, trigger, className, content, showArrow, classNameTitle, getPopupContainer, autoDestroy, autoLock, }: PopoverProps) => import("react/jsx-runtime").JSX.Element;
export default Popover;
