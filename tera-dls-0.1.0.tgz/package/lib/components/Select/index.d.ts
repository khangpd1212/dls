import { Placement } from '@floating-ui/react-dom';
import { DivProps } from 'common/interfaces';
import { ChangeEvent, MouseEvent, ReactElement, ReactNode } from 'react';
import { OptionProps } from './Option';
export interface CustomTagProps {
    label: ReactNode;
    value: any;
    disabled: boolean;
    onClose: (event?: MouseEvent<HTMLElement, MouseEvent>) => void;
    closable: boolean;
}
export interface SelectProps extends Omit<React.DetailedHTMLProps<React.InputHTMLAttributes<HTMLInputElement>, HTMLInputElement>, 'ref' | 'onSelect' | 'onChange' | 'defaultValue' | 'value'> {
    showSearch?: boolean;
    searchPlaceholder?: string;
    onSearch?: (value: string) => void;
    searchValue?: string;
    allowClear?: boolean;
    options?: OptionProps[];
    onChange?: (value: BaseValueType | ChangeEvent<Element>) => void;
    onSelect?: (value: ValueType | ValueType[] | BaseValueType, option?: OptionProps) => void;
    labelInValue?: boolean;
    mode?: 'multiple';
    placement?: Placement;
    dropdownClassName?: string;
    defaultValue?: BaseValueType;
    value?: BaseValueType;
    selectedValue?: OptionProps[] | OptionProps;
    onClear?: () => void;
    onChangeCustom?: (value: ValueType | ValueType[] | BaseValueType, selectedValue?: ValueType) => void;
    notFoundContent?: ReactNode;
    divProps?: DivProps;
    tagRender?: (props: CustomTagProps) => ReactElement;
    onBlur?: (value: BaseValueType | ChangeEvent<Element>) => void;
    getPopupContainer?: () => Element | DocumentFragment;
    extraNode?: ReactNode;
    placeholderClassName?: string;
    valueClassName?: string;
    loading?: boolean;
}
export type BaseValueType = number | string | (string | number)[];
export type ValueType = OptionProps;
declare const Select: import("react").ForwardRefExoticComponent<SelectProps & import("react").RefAttributes<HTMLDivElement>>;
export default Select;
