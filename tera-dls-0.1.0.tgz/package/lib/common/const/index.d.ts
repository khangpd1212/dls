export declare const DATE_FORMAT = "DD/MM/YYYY";
export declare const MONTH_FORMAT = "MM/YYYY";
export declare const timeFormat: {
    date_time: string;
    YYYY_MM_DD: string;
    time_half: string;
    time_full: string;
};
